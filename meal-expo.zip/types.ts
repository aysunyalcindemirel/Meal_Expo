export interface Ingredient {
  item: string;
  amount?: string;
}

export interface Meal {
  id: string; // UUID or unique string
  name: string;
  description: string;
  cuisine: string;
  prepTime: string;
  ingredients: string[];
  instructions: string[]; // Step-by-step recipe
  image?: string; // Base64 data URL of the generated image
  calories?: number;
  tags: string[];
  source: 'ai' | 'manual';
  createdAt: number;
}

export type ViewState = 'suggest' | 'library' | 'create';

export interface SuggestionConfig {
  dietary?: string;
  mealType?: string;
}