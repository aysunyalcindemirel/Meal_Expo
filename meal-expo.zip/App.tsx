import React, { useState, useEffect } from 'react';
import { generateMealSuggestion, generateMealImage } from './services/gemini';
import { Meal, ViewState } from './types';
import { MealCard } from './components/MealCard';
import { Button } from './components/Button';
import { 
  ChefHat, 
  Library, 
  Plus, 
  Sparkles, 
  UtensilsCrossed, 
  ArrowRight, 
  Save, 
  X,
  Search,
  BookOpen
} from 'lucide-react';

const STORAGE_KEY = 'flavorgenie_meals_v1';

export default function App() {
  const [view, setView] = useState<ViewState>('suggest');
  const [savedMeals, setSavedMeals] = useState<Meal[]>([]);
  const [currentSuggestion, setCurrentSuggestion] = useState<Meal | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isImageLoading, setIsImageLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Form State
  const [customMealName, setCustomMealName] = useState('');
  const [customMealDesc, setCustomMealDesc] = useState('');
  const [customMealIngredients, setCustomMealIngredients] = useState('');
  const [customMealInstructions, setCustomMealInstructions] = useState('');

  // Load from local storage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        setSavedMeals(JSON.parse(stored));
      }
    } catch (e) {
      console.error("Failed to load meals", e);
    }
  }, []);

  // Save to local storage whenever list changes
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(savedMeals));
  }, [savedMeals]);

  const handleGetSuggestion = async () => {
    setIsLoading(true);
    setIsImageLoading(false);
    setError(null);
    try {
      // Pass list of recent meal names to exclude
      const exclusions = savedMeals.slice(-5).map(m => m.name);
      
      // If we already have a suggestion displayed, add it to exclusion too
      if (currentSuggestion) {
        exclusions.push(currentSuggestion.name);
      }

      // 1. Generate text suggestion (Fast)
      const suggestionData = await generateMealSuggestion(exclusions);
      
      const newMealId = crypto.randomUUID();

      const newMeal: Meal = {
        ...suggestionData,
        id: newMealId,
        source: 'ai',
        image: undefined, // Image comes later
        createdAt: Date.now()
      };
      
      // Update UI immediately with the text
      setCurrentSuggestion(newMeal);
      setView('suggest');
      setIsLoading(false); 

      // 2. Trigger image generation in background (Slower)
      setIsImageLoading(true);
      generateMealImage(suggestionData.name, suggestionData.description)
        .then(generatedImage => {
           if (generatedImage) {
             setCurrentSuggestion(prev => {
                // Only update if the user is still looking at the same meal
                if (prev && prev.id === newMealId) {
                  return { ...prev, image: generatedImage };
                }
                return prev;
             });
           }
        })
        .catch(err => console.warn("Background image generation failed", err))
        .finally(() => setIsImageLoading(false));

    } catch (err) {
      console.error(err);
      setError("Failed to generate a meal. Please check your connection or try again.");
      setIsLoading(false);
    }
  };

  const handleSaveMeal = (meal: Meal) => {
    // Check for duplicates based on name (simple check)
    if (savedMeals.some(m => m.name.toLowerCase() === meal.name.toLowerCase())) {
      alert("You already have this meal in your library!");
      return;
    }
    setSavedMeals(prev => [meal, ...prev]);
    setView('library'); 
  };

  const handleDeleteMeal = (id: string) => {
    setSavedMeals(prev => prev.filter(m => m.id !== id));
  };

  const handleCreateCustomMeal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customMealName.trim()) return;

    const newMeal: Meal = {
      id: crypto.randomUUID(),
      name: customMealName,
      description: customMealDesc || 'A delicious custom creation.',
      cuisine: 'Custom',
      prepTime: 'Unknown',
      ingredients: customMealIngredients.split('\n').filter(s => s.trim()),
      instructions: customMealInstructions.split('\n').filter(s => s.trim()),
      tags: ['Personal'],
      source: 'manual',
      createdAt: Date.now()
    };

    handleSaveMeal(newMeal);
    
    // Reset form
    setCustomMealName('');
    setCustomMealDesc('');
    setCustomMealIngredients('');
    setCustomMealInstructions('');
    setView('library');
  };

  const filteredMeals = savedMeals.filter(m => 
    m.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    m.cuisine.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const renderContent = () => {
    if (view === 'suggest') {
      return (
        <div className="max-w-xl mx-auto w-full pb-24 px-4">
          {!currentSuggestion && !isLoading ? (
            <div className="text-center mt-12 sm:mt-24 space-y-8">
              <div className="relative inline-block">
                <div className="absolute inset-0 bg-orange-200 rounded-full blur-xl opacity-50 animate-pulse"></div>
                <div className="relative bg-white p-6 rounded-full shadow-xl shadow-orange-100 border border-orange-50">
                  <ChefHat size={64} className="text-orange-500" />
                </div>
              </div>
              
              <div className="space-y-4">
                <h1 className="text-4xl sm:text-5xl font-black text-stone-900 tracking-tight">
                  Hungry?
                </h1>
                <p className="text-lg text-stone-500 max-w-sm mx-auto">
                  Can't decide what to eat? Let our AI chef curate the perfect meal and recipe for you.
                </p>
              </div>

              <div className="pt-8">
                <Button 
                  onClick={handleGetSuggestion} 
                  isLoading={isLoading}
                  className="w-full sm:w-auto text-lg px-8 py-4 shadow-orange-300 shadow-2xl"
                  icon={<Sparkles className="w-5 h-5" />}
                >
                  Inspire Me
                </Button>
              </div>
            </div>
          ) : isLoading ? (
             <div className="flex flex-col items-center justify-center min-h-[50vh] space-y-6">
                <div className="relative">
                  <div className="w-16 h-16 border-4 border-orange-200 border-t-orange-600 rounded-full animate-spin"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <UtensilsCrossed size={20} className="text-orange-600 opacity-50" />
                  </div>
                </div>
                <p className="text-stone-500 font-medium animate-pulse">Designing your meal & recipe...</p>
             </div>
          ) : currentSuggestion ? (
            <div className="space-y-6 pt-4 sm:pt-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
               <MealCard 
                 meal={currentSuggestion} 
                 actionLabel="Save to Library"
                 actionIcon={<Save size={20} />}
                 onAction={() => handleSaveMeal(currentSuggestion!)}
                 loadingImage={isImageLoading}
               />
               
               <div className="flex justify-center pb-8">
                  <Button 
                    variant="ghost" 
                    onClick={handleGetSuggestion}
                    className="text-stone-400 hover:text-stone-600"
                    disabled={isImageLoading} // Optional: prevent spamming while image loads if desired, but user can technically skip
                  >
                    Not feeling it? Try another <ArrowRight size={16} className="ml-2" />
                  </Button>
               </div>
            </div>
          ) : null}
          {error && (
            <div className="mt-8 p-4 bg-red-50 text-red-600 rounded-xl text-center border border-red-100">
              {error}
              <button onClick={() => setError(null)} className="ml-2 underline">Dismiss</button>
            </div>
          )}
        </div>
      );
    }

    if (view === 'create') {
      return (
        <div className="max-w-xl mx-auto w-full px-4 pt-8 pb-24">
          <div className="bg-white rounded-2xl shadow-sm border border-stone-100 p-6 sm:p-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-stone-800">Add Meal Manually</h2>
              <button onClick={() => setView('library')} className="p-2 hover:bg-stone-100 rounded-full text-stone-500">
                <X size={20} />
              </button>
            </div>
            
            <form onSubmit={handleCreateCustomMeal} className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-stone-700 mb-1">Meal Name</label>
                <input 
                  type="text" 
                  value={customMealName}
                  onChange={(e) => setCustomMealName(e.target.value)}
                  placeholder="e.g. Grandma's Lasagna"
                  className="w-full px-4 py-3 rounded-xl bg-stone-50 border border-stone-200 focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none transition-all"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-stone-700 mb-1">Description</label>
                <textarea 
                  value={customMealDesc}
                  onChange={(e) => setCustomMealDesc(e.target.value)}
                  placeholder="Describe the dish..."
                  rows={3}
                  className="w-full px-4 py-3 rounded-xl bg-stone-50 border border-stone-200 focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none transition-all resize-none"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-stone-700 mb-1">Ingredients (one per line)</label>
                <textarea 
                  value={customMealIngredients}
                  onChange={(e) => setCustomMealIngredients(e.target.value)}
                  placeholder="2 cups Flour&#10;1 cup Milk"
                  rows={4}
                  className="w-full px-4 py-3 rounded-xl bg-stone-50 border border-stone-200 focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none transition-all resize-none"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-stone-700 mb-1">Instructions (one per line)</label>
                <textarea 
                  value={customMealInstructions}
                  onChange={(e) => setCustomMealInstructions(e.target.value)}
                  placeholder="1. Mix ingredients...&#10;2. Bake for 30 mins..."
                  rows={4}
                  className="w-full px-4 py-3 rounded-xl bg-stone-50 border border-stone-200 focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none transition-all resize-none"
                />
              </div>

              <div className="pt-2">
                <Button type="submit" className="w-full text-lg">
                  Add to Library
                </Button>
              </div>
            </form>
          </div>
        </div>
      )
    }

    // Library View
    return (
      <div className="max-w-5xl mx-auto w-full px-4 pb-24 pt-6 sm:pt-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-stone-900">Your Menu</h1>
            <p className="text-stone-500 mt-1">
              {savedMeals.length} {savedMeals.length === 1 ? 'meal' : 'meals'} saved
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setView('create')} icon={<Plus size={18} />}>
              Add Custom
            </Button>
          </div>
        </div>

        {savedMeals.length > 0 && (
          <div className="mb-6 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400 w-5 h-5" />
            <input 
              type="text"
              placeholder="Search your meals..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 rounded-xl bg-white border border-stone-200 focus:ring-2 focus:ring-orange-500 outline-none"
            />
          </div>
        )}

        {savedMeals.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-stone-200">
            <div className="bg-stone-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <BookOpen className="text-stone-400" size={24} />
            </div>
            <h3 className="text-lg font-bold text-stone-800 mb-2">Library is empty</h3>
            <p className="text-stone-500 mb-6">Start by getting suggestions from the AI Chef.</p>
            <Button onClick={() => setView('suggest')} variant="secondary">
              Get Suggestions
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredMeals.map(meal => (
              <MealCard 
                key={meal.id} 
                meal={meal} 
                variant="compact"
                onDelete={() => handleDeleteMeal(meal.id)}
                className="hover:shadow-md transition-shadow duration-300"
              />
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-stone-50 flex flex-col font-sans">
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-b border-stone-100">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
           <div 
             className="flex items-center gap-2 cursor-pointer group"
             onClick={() => setView('suggest')}
           >
             <div className="bg-orange-600 text-white p-1.5 rounded-lg group-hover:rotate-12 transition-transform">
                <ChefHat size={20} />
             </div>
             <span className="font-bold text-xl text-stone-900 tracking-tight">
               Meal Expo
             </span>
           </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col">
        {renderContent()}
      </main>

      {/* Bottom Navigation for Mobile/Desktop */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-stone-100 pb-safe z-40">
        <div className="max-w-md mx-auto flex justify-around p-2">
          <button 
            onClick={() => setView('suggest')}
            className={`flex flex-col items-center p-3 rounded-xl flex-1 transition-colors ${view === 'suggest' ? 'text-orange-600 bg-orange-50' : 'text-stone-400 hover:text-stone-600'}`}
          >
            <Sparkles size={24} className={view === 'suggest' ? 'fill-orange-600/20' : ''} />
            <span className="text-xs font-medium mt-1">Suggest</span>
          </button>
          
          <button 
            onClick={() => setView('library')}
            className={`flex flex-col items-center p-3 rounded-xl flex-1 transition-colors ${view === 'library' || view === 'create' ? 'text-orange-600 bg-orange-50' : 'text-stone-400 hover:text-stone-600'}`}
          >
            <Library size={24} className={view === 'library' ? 'fill-orange-600/20' : ''} />
            <span className="text-xs font-medium mt-1">Library</span>
          </button>
        </div>
      </nav>
    </div>
  );
}