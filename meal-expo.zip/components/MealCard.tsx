import React, { useState } from 'react';
import { Clock, Flame, Utensils, Tag, Trash2, Plus, ChevronDown, ChevronUp, ChefHat, Sparkles, Image as ImageIcon } from 'lucide-react';
import { Meal } from '../types';

interface MealCardProps {
  meal: Meal;
  onAction?: () => void;
  actionLabel?: string;
  actionIcon?: React.ReactNode;
  variant?: 'full' | 'compact';
  onDelete?: () => void;
  className?: string;
  loadingImage?: boolean;
}

export const MealCard: React.FC<MealCardProps> = ({ 
  meal, 
  onAction, 
  actionLabel, 
  actionIcon, 
  variant = 'full',
  onDelete,
  className = '',
  loadingImage = false
}) => {
  const [showRecipe, setShowRecipe] = useState(false);

  // Use generated image if available, else deterministic fallback
  const fallbackImageId = meal.name.length % 50 + 10; 
  const imageUrl = meal.image || `https://picsum.photos/id/${fallbackImageId}/800/600`;

  const toggleRecipe = () => setShowRecipe(!showRecipe);

  if (variant === 'compact') {
    return (
      <div className={`bg-white rounded-xl shadow-sm border border-stone-100 overflow-hidden flex flex-col ${className}`}>
        <div className="relative h-40 w-full overflow-hidden bg-stone-100 group">
          <img src={imageUrl} alt={meal.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" loading="lazy" />
          <div className="absolute top-2 right-2 flex gap-1">
            <span className="bg-white/90 backdrop-blur-sm text-stone-800 text-xs font-bold px-2 py-1 rounded-full shadow-sm">
              {meal.cuisine}
            </span>
          </div>
        </div>
        <div className="p-4 flex-1 flex flex-col">
          <div className="flex justify-between items-start mb-2">
            <h3 className="font-bold text-stone-800 line-clamp-1 text-lg">{meal.name}</h3>
          </div>
          <p className="text-stone-500 text-sm line-clamp-2 mb-3 flex-1">{meal.description}</p>
          
          <div className="flex items-center justify-between mt-auto pt-3 border-t border-stone-100">
            <div className="flex gap-3 text-xs text-stone-500">
              <span className="flex items-center"><Clock size={12} className="mr-1" /> {meal.prepTime}</span>
              {meal.calories && <span className="flex items-center"><Flame size={12} className="mr-1" /> {meal.calories}</span>}
            </div>
            <div className="flex gap-2">
               <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleRecipe();
                  }}
                  className="text-stone-400 hover:text-orange-500 p-1 rounded-full hover:bg-orange-50 transition-colors"
                  title="View Details"
               >
                 {showRecipe ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
               </button>
               {onDelete && (
                 <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onDelete();
                  }}
                  className="text-stone-400 hover:text-red-500 p-1 rounded-full hover:bg-red-50 transition-colors"
                >
                  <Trash2 size={16} />
                </button>
              )}
            </div>
          </div>
          
          {/* Expanded Recipe View in Compact Card */}
          {showRecipe && (
             <div className="mt-4 pt-4 border-t border-stone-100 text-sm animate-in fade-in slide-in-from-top-2">
                <div className="mb-3">
                  <h4 className="font-bold text-stone-700 mb-1">Ingredients</h4>
                  <ul className="list-disc list-inside text-stone-600 text-xs space-y-0.5 pl-1">
                    {meal.ingredients.slice(0, 4).map((i, idx) => <li key={idx}>{i}</li>)}
                    {meal.ingredients.length > 4 && <li>...and more</li>}
                  </ul>
                </div>
                <button 
                  onClick={() => alert('Please view the full card to see all details.')} 
                  className="w-full text-center text-orange-600 text-xs font-medium hover:underline"
                >
                  View Full Recipe
                </button>
             </div>
          )}
        </div>
      </div>
    );
  }

  // Full variant (Suggestion View)
  return (
    <div className={`bg-white rounded-3xl shadow-xl shadow-stone-200/50 overflow-hidden border border-stone-100 ${className}`}>
      <div className="relative h-64 sm:h-80 w-full overflow-hidden group bg-stone-100">
        {loadingImage ? (
           <div className="absolute inset-0 bg-stone-100 animate-shimmer z-20 flex flex-col items-center justify-center text-stone-400">
              <div className="bg-white p-3 rounded-full shadow-sm mb-2 animate-bounce">
                <ImageIcon size={24} className="text-orange-400" />
              </div>
              <div className="flex items-center space-x-2">
                <Sparkles size={16} className="text-orange-400 animate-spin" />
                <span className="text-xs font-bold tracking-wide uppercase">Designing Plate...</span>
              </div>
           </div>
        ) : (
          <>
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent z-10" />
            <img 
              src={imageUrl} 
              alt={meal.name} 
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 animate-in fade-in duration-700" 
            />
          </>
        )}
        
        <div className="absolute bottom-6 left-6 right-6 z-20 text-white">
          <div className="flex items-center gap-2 mb-3">
            <span className="px-2.5 py-1 rounded-lg bg-orange-500 text-xs font-bold uppercase tracking-wider shadow-sm">
              {meal.cuisine}
            </span>
            {meal.source === 'ai' && (
              <span className="px-2.5 py-1 rounded-lg bg-white/20 backdrop-blur-md text-xs font-bold uppercase tracking-wider shadow-sm border border-white/20">
                AI Chef
              </span>
            )}
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold leading-tight text-shadow-sm">{meal.name}</h2>
        </div>
      </div>

      <div className="p-6 sm:p-8 space-y-8">
        <p className="text-stone-600 text-lg leading-relaxed font-medium">
          {meal.description}
        </p>

        <div className="flex flex-wrap gap-4 p-4 bg-stone-50 rounded-2xl border border-stone-100">
          <div className="flex items-center text-stone-700 font-semibold">
            <Clock className="w-5 h-5 text-orange-500 mr-2" />
            {meal.prepTime}
          </div>
          {meal.calories && (
            <div className="flex items-center text-stone-700 font-semibold">
              <Flame className="w-5 h-5 text-red-500 mr-2" />
              {meal.calories} kcal
            </div>
          )}
          <div className="flex items-center text-stone-700 font-semibold">
            <Utensils className="w-5 h-5 text-blue-500 mr-2" />
            {meal.ingredients.length} Items
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Ingredients Section */}
          <div>
            <h3 className="text-sm font-bold text-stone-400 uppercase tracking-wider mb-4 flex items-center">
              <div className="w-1.5 h-1.5 rounded-full bg-orange-500 mr-2" /> Ingredients
            </h3>
            <ul className="space-y-3">
              {meal.ingredients.map((ing, idx) => (
                <li key={idx} className="flex items-start text-stone-700 text-sm p-3 rounded-xl bg-stone-50 border border-stone-100">
                  <span className="block w-1.5 h-1.5 mt-1.5 rounded-full bg-stone-300 mr-3 flex-shrink-0" />
                  {ing}
                </li>
              ))}
            </ul>
          </div>

          {/* Instructions / Recipe Section */}
          <div>
            <h3 className="text-sm font-bold text-stone-400 uppercase tracking-wider mb-4 flex items-center">
              <div className="w-1.5 h-1.5 rounded-full bg-orange-500 mr-2" /> Preparation
            </h3>
            {meal.instructions && meal.instructions.length > 0 ? (
               <div className="space-y-4">
                 {meal.instructions.map((step, idx) => (
                   <div key={idx} className="flex gap-4">
                     <div className="flex-shrink-0 w-6 h-6 rounded-full bg-stone-900 text-white flex items-center justify-center text-xs font-bold mt-0.5">
                       {idx + 1}
                     </div>
                     <p className="text-stone-600 text-sm leading-relaxed">{step}</p>
                   </div>
                 ))}
               </div>
            ) : (
              <p className="text-stone-400 italic">No instructions provided.</p>
            )}
          </div>
        </div>

        <div>
           <h3 className="text-sm font-bold text-stone-400 uppercase tracking-wider mb-3">Tags</h3>
           <div className="flex flex-wrap gap-2">
            {meal.tags.map((tag, idx) => (
              <div key={idx} className="flex items-center text-xs text-stone-500 bg-white px-3 py-1.5 rounded-full border border-stone-200">
                <Tag size={12} className="mr-1.5 opacity-50" />
                {tag}
              </div>
            ))}
           </div>
        </div>

        {onAction && (
          <div className="pt-4 border-t border-stone-100">
            <button
              onClick={onAction}
              className="w-full bg-stone-900 text-white py-4 rounded-xl font-bold text-lg hover:bg-stone-800 transition-all flex items-center justify-center gap-2 shadow-xl shadow-stone-200 active:scale-[0.99]"
            >
              {actionIcon || <Plus size={20} />}
              {actionLabel || 'Add to Library'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};